    
export function round2(n: number) {
    return Math.round(n*100) / 100;
}

export function round0(n: number) {
    return Math.round(n);
}
